import numpy as np
import pandas as pd
import nltk
import re
import os
import codecs
from sklearn import feature_extraction
loc='C:/Users/saragada/Desktop/HPI/Search/Search Results/'

files = [x for x in os.listdir(loc)]
totdata=pd.DataFrame()
print(files)
for i in files:
    datap=pd.read_csv(loc+str(i),skiprows=0,skip_blank_lines=True, sep=None, dtype=None, quotechar='"',engine='python')
    datap.dropna(axis=0, how='any', subset=['Desc'])
    datap=datap[['Word','Desc']]
    datap=datap.dropna(how='any')
    totdata=pd.concat([datap,totdata],ignore_index=True)
df = totdata.drop_duplicates('Word')
df=df.reset_index()
df['Word'] = df['Word'].astype(str)
df['Desc'] = df['Desc'].astype(str)
    
    


stopwords = nltk.corpus.stopwords.words('english')
from nltk.stem.snowball import SnowballStemmer
stemmer = SnowballStemmer("english")
def tokenize_only(text):
    # first tokenize by sentence, then by word to ensure that punctuation is caught as it's own token
    tokens = [word.lower() for sent in nltk.sent_tokenize(text) for word in nltk.word_tokenize(sent)]
    filtered_tokens = []
    # filter out any tokens not containing letters (e.g., numeric tokens, raw punctuation)
    for token in tokens:
        if re.search('[a-zA-Z]', token):
            filtered_tokens.append(token)
    return filtered_tokens

totalvocab_stemmed = []
allwords_tokenized1=[]
totalvocab_tokenized = []
for i in df['Desc']:

    allwords_tokenized = tokenize_only(i)
    allwords_tokenized1.append(tokenize_only(i))
    totalvocab_tokenized.extend(allwords_tokenized)
    
    
from sklearn.feature_extraction.text import TfidfVectorizer

#define vectorizer parameters
tfidf_vectorizer = TfidfVectorizer(max_df=0.8, max_features=200000,
                                 min_df=0, stop_words='english',
                                 use_idf=True, tokenizer=tokenize_only, ngram_range=(1,3))

#tfidf_matrix = tfidf_vectorizer.inverse_transform(data['text'])
tfidf_matrix = tfidf_vectorizer.fit_transform(df['Desc']) #fit the vectorizer to synopses

terms = tfidf_vectorizer.get_feature_names()


Signi_tokenized= []
for i in allwords_tokenized1:
    Signi = set(i) & set(terms)
    Signi_tokenized.append([Signi])
    

    


Signi_tokenized=pd.DataFrame(Signi_tokenized)
Signi_tokenized['Word']=df['Word']
Signi_tokenized['Desc']=df['Desc']


Signi_tokenized.to_csv('tokenzers2.csv')
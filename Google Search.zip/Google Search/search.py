from newspaper import *
import pandas as pd
import requests

try:
    from google import search
except ImportError: 
    print("No module named 'google' found")
 
# to search
data=pd.read_excel('C:/Users/saragada/Desktop/HPI/Search/To be searched.xlsx',sheetname='AssetClassMaster')



description=[]
word=[]

for query in  data['Asset description']:
    query=str(query)
    print(query)  
    
    for j in search(query, tld="com", num=1,stop=1, pause=2):
            print(j)
            try:
                
                try:
#                    webf=urllib.urlopen(j)
#                    txt1=webf.read()
                    article1 = Article(j)
                    article1.download()
                    article1.parse()
                    txt1=article1.text
                    description.append(txt1)
                    word.append(query)
                
                except:
                    description.append('Failed')
                    word.append(query)
            except:
                pass

        


dataout=pd.DataFrame()
dataout['Word']=word
dataout['Desc']=description
dataout.to_csv('searchresults.csv')


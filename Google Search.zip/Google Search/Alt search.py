import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory



# Any results you write to the current directory are saved as output.

import re
import requests
from collections import OrderedDict
from bs4 import BeautifulSoup
from newspaper import *
import pandas as pd
from  tkinter import *
import logging
logging.getLogger('requests.packages.urllib3.connectionpool').setLevel(logging.ERROR)
global keyword1,keyword2
global news1,href1,ntitle1,ndt1,news2,href2,ntitle2,ndt2,notscraped
news1=[]
href1=[]

ntitle1=[]
ndt1=[]

news2=[]
href2=[]

ntitle2=[]
ndt2=[]
notscraped=[]



data=pd.read_excel('C:/Users/saragada/Desktop/HPI/Search/External MasterFile complete.xlsx',sheetname='AssetClassMaster')

query = data['Asset description']

description=[]
word=[]

for query in  data['Asset description'][:5]:
    query=str(query)
    print(query) 
    url='https://www.bing.com/search?q='+ str(query)
    sourcecode = requests.get(url)
    plane_text= sourcecode.text
    soup= BeautifulSoup(plane_text,'lxml')
    
    for link in soup.findAll('a'):
        href=link.get('href')
        href1.append(href)
        href1=list(href1)

    
    href1=list(OrderedDict.fromkeys(href1))
    for j in href1:
        
        if re.search("https://",str(j)):
            print(j)
            try:
                    webf=urllib.urlopen(j)
                    txt1=webf.read()
#                    article1 = Article(j)
#                    article1.download()
#                    article1.parse()
#                    txt1=article1.text
                    description.append(txt1)
                    word.append(query)
            except:
                    description.append('Failed')
                    word.append(query)
        
        


dataout=pd.DataFrame()
dataout['Word']=word
dataout['Desc']=description
dataout.to_csv('searchbing.csv')

    

    

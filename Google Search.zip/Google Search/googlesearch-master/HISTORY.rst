=======
History
=======

1.0.0 (2017-05-06)
------------------

* First release on PyPI.

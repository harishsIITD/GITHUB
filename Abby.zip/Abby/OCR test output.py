import os
import pandas as pd
import webbrowser
import re
from ABBYY import CloudOCR
ocr_engine = CloudOCR(application_id='********', password='***************')
files = [x for x in os.listdir('C:/Users/saragada/Desktop/HPI/AP Indexing/Start/abbyyPocInvoice/singapore/')]

filename=[]
link=[]
xmllink=[]
convdata=pd.DataFrame()
for i in files[:30]:
    pdf = open('C:/Users/saragada/Desktop/HPI/AP Indexing/Start/abbyyPocInvoice/singapore/'+str(i), 'rb')
    file = {pdf.name: pdf}
    result = ocr_engine.process_and_download(file, exportFormat='xlsx,xml')
    output=ocr_engine.listTasks()
    l=output[-1:][0].get('resultUrl')
    xml=output[-1:][0].get('resultUrl2')
    filename.append(i)
    link.append(l)
    xmllink.append(xml)
    
convdata['filename']=filename
convdata['link']=link
convdata['xmllink']=xmllink

formattedlink=[]

for j in convdata['link']:
    
    webbrowser.open(j,new=2)    
    str2=re.split("/",j)
    str3=re.split(".result",str2[4])
    formattedlink.append(str3[0])
convdata['Formatted-link']=formattedlink
convdata.to_csv('C:/Users/saragada/Desktop/HPI/AP Indexing/Downloads/singapore/IndexAPI.csv')



    







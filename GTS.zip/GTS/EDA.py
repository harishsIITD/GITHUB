import pandas as pd
import numpy as np
import pandas as pd
import nltk
import re
import os
import codecs
from sklearn import feature_extraction

data2=pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/GTS data/SPLAUD_SPL_RES_SYSTEM_1_SPL_RES_USER_2.csv',encoding='latin-1')
dataNA=pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/GTS data/SPLAUD_SPL_RES_SYSTEM_1_SPL_RES_USER_NA.csv',encoding='latin-1')
data=data2.append(dataNA, ignore_index=True)
#data=pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/ggtSample.csv',encoding='latin-1')
mapdata1=pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/OneDrive_3_2-15-2018/TSPLA.csv',encoding='latin-1')
mapdata2=pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/OneDrive_3_2-15-2018/TSPLN.csv',encoding='latin-1')
#data=data[~data['Outcome of System SPL Screening for Legal Control'].isnull()]
mapdata=pd.merge(mapdata2,mapdata1,on='GUID_TSPL',how='inner', indicator=True)
#basedata=data[['Name 1','Name 2','Name 3','Name 4','Converted name field (with form of address)','c/o name','City','District','City code for city/street file','District code for City and Street file','City (different from postal city)','Different city for city/street file','City file test status','Regional structure grouping','City postal code','PO Box Postal Code','Company Postal Code (for Large Customers)','PO Box','PO Box Address Undeliverable Flag','Flag: PO Box Without Number','PO Box city','City PO box code (City file)','Region for PO Box (Country, State, Province, ...)','PO box country','(Not Supported) Post Delivery District','Transportation zone to or from which the goods are delivered','Street','Street Address Undeliverable Flag','Street Number for City/Street File','(Not Supported) Abbreviation of Street Name','House Number','House number supplement','(Not supported) House Number Range','Street 2','Street 3','Street 4','Street 5','Building (Number or Code)','Floor in building','Room or Appartment Number','Country Key','Region (State, Province, County)']]
#basedata=data[['NAME1','NAME2','NAME3','NAME4','NAME_TXT','NAME_CO','CITY1','CITY2','CITY_CODE','POST_CODE1','POST_CODE2','POST_CODE3','PCODE1_EXT','PCODE2_EXT','PCODE3_EXT','PO_BOX','DONT_USE_P','PO_BOX_NUM','PO_BOX_LOC','CITY_CODE2','PO_BOX_REG','PO_BOX_CTY','POSTALAREA','STREET','DONT_USE_S','STREETCODE','STREETABBR','HOUSE_NUM1','HOUSE_NUM2','HOUSE_NUM3','STR_SUPPL1','STR_SUPPL2','STR_SUPPL3','LOCATION','BUILDING','FLOOR','SORT1','SORT2','SORT_PHN','ADDRORIGIN','EXTENSION1','EXTENSION2','COUNTY','TOWNSHIP_CODE','TOWNSHIP','MC_COUNTY','MC_TOWNSHIP']]
basedata=data[['NAME1','NAME2','NAME3','NAME4','COUNTRY']]
mapdict=pd.DataFrame()
#mapdatastemmed=mapdata[['SPL_STREET1','SPL_STREET2','SPL_STREET3','SPL_PO_BOX','SPL_PO_CITY','SPL_PO_CODE','SPL_PO_COUNTRY','SPL_PO_REGION','SPL_HOUSE_NUMBER','SPL_BUILDING','SPL_ROOM_NUMBER','SPL_PHONE','SPL_FAX','SPL_TELEX','SPL_EMAIL','SPL_PAGER','SPL_POST_CODE','SPL_CITY','SPL_DISTRICT','SPL_COUNTRY','SPL_REGION','SPL_NAME1','SPL_NAME2','SPL_NAME3','SPL_NAME4','SPL_NAME_CO','SPL_PASS_COUNTRY']]
mapdatastemmed=mapdata[['SPL_NAME1','SPL_NAME2','SPL_NAME3','SPL_NAME4','SPL_COUNTRY']]
mapcolist=mapdatastemmed.columns.values.tolist()
mapdict['Combined'] = mapdatastemmed[mapdatastemmed.columns].apply(lambda x: ' '.join(x.dropna().astype(str)),axis=1)
basecolist=basedata.columns.values.tolist()
basedata['Combined']=basedata[basedata.columns].apply(lambda x: ' '.join(x.dropna().astype(str)),axis=1)
stopwords = nltk.corpus.stopwords.words('english')
from nltk.stem.snowball import SnowballStemmer
stemmer = SnowballStemmer("english")
def tokenize_only(text):
    # first tokenize by sentence, then by word to ensure that punctuation is caught as it's own token
    tokens = [word.lower() for sent in nltk.sent_tokenize(text) for word in nltk.word_tokenize(sent)]
    filtered_tokens = []
    # filter out any tokens not containing letters (e.g., numeric tokens, raw punctuation)
    for token in tokens:
        if re.search('[a-zA-Z]', token):
            filtered_tokens.append(token)
    return filtered_tokens

totalvocab_stemmed = []
allwords_tokenized1=[]
totalvocab_tokenized = []
for i in basedata['Combined']:

    allwords_tokenized = tokenize_only(i)
    allwords_tokenized1.append(tokenize_only(i))
    totalvocab_tokenized.extend(allwords_tokenized)
    
    
from sklearn.feature_extraction.text import TfidfVectorizer

#define vectorizer parameters
tfidf_vectorizer = TfidfVectorizer(max_df=0.8, max_features=200,
                                 min_df=0, stop_words='english',
                                 use_idf=True, tokenizer=tokenize_only,ngram_range=(1,3))

#tfidf_matrix = tfidf_vectorizer.inverse_transform(data['text'])
tfidf_matrix = tfidf_vectorizer.fit_transform(mapdict['Combined']) #fit the vectorizer to synopses

terms = tfidf_vectorizer.get_feature_names()


Signi_tokenized= []
for i in allwords_tokenized1:
    Signi = set(i) & set(terms)
    Signi_tokenized.append([Signi])
    

    


Signi_tokenized=pd.DataFrame(Signi_tokenized)


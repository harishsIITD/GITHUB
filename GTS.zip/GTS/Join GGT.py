import pandas as pd

splaud = pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/ggtSample.csv',encoding='latin-1')
splaudd = pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/SPLAUDD.csv',encoding='latin-1')
tspl =  pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/OneDrive_3_2-15-2018/TSPL.csv',encoding='latin-1')
tspln =  pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/OneDrive_3_2-15-2018/TSPLN.csv',encoding='latin-1')
tspla =  pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/OneDrive_3_2-15-2018/TSPLA.csv',encoding='latin-1')

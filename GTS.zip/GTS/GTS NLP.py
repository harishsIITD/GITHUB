import pandas as pd
import numpy as np
import nltk
import re
import os
import codecs

data2=pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/GTS data/SPLAUD_SPL_RES_SYSTEM_1_SPL_RES_USER_2.csv',encoding='latin-1')
dataNA=pd.read_csv('C:/Users/saragada/Desktop/HPI/GTS/GTS data/SPLAUD_SPL_RES_SYSTEM_1_SPL_RES_USER_NA.csv',encoding='latin-1')
import numpy as np
import matplotlib.pyplot as pp
import pandas as pd
import seaborn
import xlrd

import os

loc='C:/Users/saragada/Desktop/HPI/Big Deal/Sheila Wall/Deal Data/'

files = [x for x in os.listdir(loc)]
j=0
totdata=pd.DataFrame()
length=0
for i in files:
    data=pd.read_excel('C:/Users/saragada/Desktop/HPI/Big Deal/Sheila Wall/Deal Data/'+str(i),sheetname='Report')
    data['Company']=i
    totdata=pd.concat([data,totdata],ignore_index=False)
    
totdata=totdata[totdata['Manufacturing Product ID Product Type Identifier']=='UN']
totdata=totdata[totdata['Deal Line Type Code']=='PN']
Deal_Pivot=pd.pivot_table(totdata,values='Latest Authorized Unit BDNet Price US Dollar Amount',index=['Company','Deal ID','Manufacturing Product ID','Manufacturing Product Product Line Identifier','Manufacturing Product ID Product Type Identifier','Deal Line Type Code','Deal Version Number ','Line Authorized Calendar Date MM DD YYYY Code'],aggfunc='sum')
Deal_Pivot['Diff Value'] = Deal_Pivot.groupby(['Company','Deal ID','Manufacturing Product ID'])['Latest Authorized Unit BDNet Price US Dollar Amount'].diff()
Deal_Pivot.fillna(value=0, inplace=True)
Deal_Pivot['status']='No'
Deal_Pivot['status'][Deal_Pivot['Diff Value']>0]='Yes'
Deal_Pivot.to_csv('dealer.csv')


totdata=pd.read_csv('C:/Users/saragada/Desktop/HPI/Big Deal/pythondeal.csv')
totdata=totdata.apply(lambda x: x.apply(lambda y: y.strip() if type(y) == type('') else y), axis=0)
totdata=totdata[totdata['Manufacturing Product ID Product Type Identifier']=='UN']
totdata=totdata[totdata['Deal Line Type Code']=='PN']
Deal_Pivot=pd.pivot_table(totdata,values='Latest Authorized Unit BDNet Price US Dollar Amount',index=['Eclipse Customer Name','Deal ID','Manufacturing Product ID','Manufacturing Product Product Line Identifier','Manufacturing Product ID Product Type Identifier','Deal Line Type Code','Deal Version Number','Line Authorized Calendar Date MM DD YYYY Code'],aggfunc='sum')
Deal_Pivot['Diff Value'] = Deal_Pivot.groupby(['Eclipse Customer Name','Deal ID','Manufacturing Product ID'])['Latest Authorized Unit BDNet Price US Dollar Amount'].diff()
Deal_Pivot.fillna(value=0, inplace=True)
Deal_Pivot['status']='No'
Deal_Pivot['status'][Deal_Pivot['Diff Value']>0]='Yes'

Deal_Pivot.loc[(Deal_Pivot['Diff Value']>0),'Inc or dec']='Price Increased'
Deal_Pivot.loc[(Deal_Pivot['Diff Value']<0),'Inc or dec']='Price Decreased'
Deal_Pivot.loc[Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount']==0,'Inc or dec']='SKU Removed'
Deal_Pivot.loc[(Deal_Pivot['Diff Value']==0),'Inc or dec']='No Change'
Deal_Pivot['BDL Price Before the change']=Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount']-Deal_Pivot['Diff Value']
deallen=len(Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'])
Deal_Pivot=Deal_Pivot.reset_index()
Deal_Pivot['combined']=Deal_Pivot['Deal ID'].astype(str)+'_'+Deal_Pivot['Manufacturing Product ID']

unique_list=Deal_Pivot['combined'].unique()
c=0
for i in range(1,deallen):
    if Deal_Pivot['combined'][i-1]==Deal_Pivot['combined'][i] and Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'][i-1]==0 and Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'][i]>0:
        Deal_Pivot['Inc or dec'][i]='Sku Added'
        
    
Deal_Pivot.to_csv('dealer.csv')
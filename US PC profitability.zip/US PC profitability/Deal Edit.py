import os
import pandas as pd
import numpy as np

Cust_data=pd.read_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Cust_table.csv',encoding='latin-1',index_col=False)

Cust_data=Cust_data.apply(lambda x: x.apply(lambda y: y.strip() if type(y) == type('') else y), axis=0)
Cust_data = Cust_data.drop('Unnamed: 0', 1)



loc='C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Big Deal complete data/Output'

files = [x for x in os.listdir(loc)]

for j in files:
    print(j)
    totdata=pd.read_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Big Deal complete data/Output/'+str(j),encoding='latin-1')

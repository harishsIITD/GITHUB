from vertica_python import connect
import jaydebeapi
table = 'Cmn_HP_Standard_Reference_Data.DEAL_D'
import pyodbc
import pandas as pd
import numpy as np

datalist=pd.read_excel('C:/Users/saragada/Desktop/HPI/Big Deal/Sheila Wall/Total Deals/Deal List.xlsx',index = False)

conn_info = {'host':'shr4-vrt-pro-006.houston.hp.com','user': 'harish.saragadam@hp.com','password': 'killer@123','database': 'shr4_vrt_pro_006','ssl': False}
connection = connect(**conn_info)
cur = connection.cursor()
c=25059
g=93

for i in range(0,3):
    l=2
    val=list()
    deal_list=datalist.iloc[c:c+l]


    for i in range(0,len(deal_list)):
        val1=",".join(str(x) for x in deal_list.iloc[i])
        val.append(val1)
    val=tuple(val)
    cur.execute('''
    SELECT DISTINCT DEALD.DEAL_ID,
    DATE1.CLDR_DT_MM_DD_YYYY_CD,
    DATE2.CLDR_DT_MM_DD_YYYY_CD,
    BMDL.BUS_MDL_DN,
    DEALD.DEAL_VERS_NR,
    DEALA.DEAL_LN_TYPE_CD,
    DEALD.MISC_CHRG_CD,
    DEALD.WIN_LOSS_STAT_CD,
    DEALD.SLS_REP_WRKFRC_FULL_NM,
    DEALD.DIST_MGR_WRKFRC_FULL_NM,
    DEALD.DEAL_CUST_NM,
    DEALD.DEAL_CUST_SEG_CD,
    DEALA.DRVD_END_CUST_ID,
    PFTC.PRFT_CTR_LVL_3_NM,
    DEALA.DEAL_LN_TYPE_NM,
	DEALA.PROD_ID,
    DATE3.CLDR_DT_MM_DD_YYYY_CD,
    DEALA.DEAL_ROLLOUT_MTH_QT,
    DEALA.QTD_GRS_REV_AT_NDP_USD_AM,
    DEALA.DEAL_GRS_REV_AT_LIST_PRC_USD_AM,
    DEALA.QTD_BDNET_REV_USD_AM,
    DEALA.DEAL_BD_NET_REV_USD_AM,
    DEALA.QTD_GRS_MRGN_USD_AM,
    DEALA.DEAL_GRS_MRGN_USD_AM,
    DEALA.DEAL_AUTH_NET_BIG_DEAL_PRC_USD_AM
      
    from Cmn_Deal.DEAL_LN_AUDIT_F DEALA 
    INNER JOIN Cmn_HP_Standard_Reference_Data.DEAL_D DEALD 
          ON (DEALD.DEAL_ID IN {} AND DEALA.DEAL_ID =DEALD.DEAL_ID AND  DEALA.DEAL_VERS_NR  =  DEALD.DEAL_VERS_NR  AND DEALD.SPRN_CO_ID IN ('1','2'))
    INNER JOIN Cmn_HP_Standard_Reference_Data.BUS_AREA_D BA
          ON ( DEALA.BUS_AREA_CD  =  BA.BUS_AREA_CD  AND BA.SPRN_CO_ID = '2' AND BA.EXT_SEG_CD  ='HPBA_WW52' )
    INNER JOIN Cmn_HP_Standard_Reference_Data.PRFT_CTR_D PFTC
          ON ( DEALA.PRFT_CTR_CD  =  PFTC.PRFT_CTR_CD  AND PFTC.SPRN_CO_ID = '2' and PFTC.PRFT_CTR_LVL_2_CD  = 'PCG00903')
    INNER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE1
          ON ( DEALD.DEAL_BEGIN_DT  =  DATE1.CLDR_DT )
    INNER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE2
          ON ( DEALD.DEAL_END_DT  =  DATE2.CLDR_DT AND DATE2.CLDR_DT > '02/01/2017' )
    INNER JOIN Cmn_HP_Standard_Reference_Data.DEAL_BUS_MDL_D BMDL
          ON ( DEALD.BUS_MDL_CD  =  BMDL.BUS_MDL_CD  AND  DEALD.ISO_CTRY_CD  =  BMDL.GEO_CD  AND BMDL.SPRN_CO_ID = '2')
    LEFT OUTER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE3
          ON ( DEALA.LN_AUTH_DT  =  DATE3.CLDR_DT )'''.format(val))
    
    c=c+l
    rows=cur.fetchall()
    totdata=pd.DataFrame(rows)
    g=g+1
    totdata.to_csv('//krishnku15/HPI/Abhishek/US Enterpise 10 2016 SO and Pdt Category Data/US Commercial PC - AUP Analysis/Big Deal 2017/Deal'+str(g)+'.csv')
totdata.columns=['Deal ID','Deal Begin Calendar Date MM DD YYYY Code','Deal End Calendar Date MM DD YYYY Code','Business Model Description','Deal Version Number','Deal Line Type Code','Miscellaneous Charge Code','Win Loss Status Code','Sales Rep Workforce Full Name','District Manager Workforce Full Name','Eclipse Customer Name','Eclipse Customer Segment Code','Customer Account Management Identifier Level 2 Identifier','Customer Account Management Identifier Level 4 Segment Code','Profit Center Level 3 Name','Deal Line Type Description','Manufacturing Product ID Product Type Identifier','Manufacturing Product Product Line Identifier','Manufacturing Product ID','Line Authorized Calendar Date MM DD YYYY Code','Manufacturing Product Product Description','Quantity','Quoted Gross Revenue @NDP US Dollar Amount','Latest Gross Revenue @ LP US Dollar Amount','	Quoted BDNet Revenue US Dollar Amount','Latest BD Net Revenue US Dollar Amount','Quoted Gross Margin US Dollar Amount','Latest Gross Margin US Dollar Amount','Latest Authorized Unit BDNet Price US Dollar Amount']
totdata=totdata.apply(lambda x: x.apply(lambda y: y.strip() if type(y) == type('') else y), axis=0)
totdata=totdata[totdata['Manufacturing Product ID Product Type Identifier']=='UN']
totdata=totdata[totdata['Deal Line Type Code']=='PN']
Deal_Pivot=pd.pivot_table(totdata,values='Latest Authorized Unit BDNet Price US Dollar Amount',index=['Eclipse Customer Name','Deal ID','Manufacturing Product ID','Manufacturing Product Product Line Identifier','Manufacturing Product ID Product Type Identifier','Deal Line Type Code','Deal Version Number','Line Authorized Calendar Date MM DD YYYY Code'],aggfunc='sum')
Deal_Pivot['Diff Value'] = Deal_Pivot.groupby(['Eclipse Customer Name','Deal ID','Manufacturing Product ID'])['Latest Authorized Unit BDNet Price US Dollar Amount'].diff()
Deal_Pivot.fillna(value=0, inplace=True)
Deal_Pivot['status']='No'
Deal_Pivot['status'][Deal_Pivot['Diff Value']>0]='Yes'

Deal_Pivot.loc[(Deal_Pivot['Diff Value']>0),'Inc or dec']='Price Increased'
Deal_Pivot.loc[(Deal_Pivot['Diff Value']<0),'Inc or dec']='Price Decreased'
Deal_Pivot.loc[Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount']==0,'Inc or dec']='SKU Removed'
Deal_Pivot.loc[(Deal_Pivot['Diff Value']==0),'Inc or dec']='No Change'
Deal_Pivot['BDL Price Before the change']=Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount']-Deal_Pivot['Diff Value']
deallen=len(Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'])
Deal_Pivot=Deal_Pivot.reset_index()
Deal_Pivot['combined']=Deal_Pivot['Deal ID'].astype(str)+'_'+Deal_Pivot['Manufacturing Product ID']

unique_list=Deal_Pivot['combined'].unique()
c=0
for i in range(1,deallen):
    if Deal_Pivot['combined'][i-1]==Deal_Pivot['combined'][i] and Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'][i-1]==0 and Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'][i]>0:
        Deal_Pivot['Inc or dec'][i]='Sku Added'
        
    
#Deal_Pivot.to_csv('dealer.csv')


import csv
import pandas as pd
data= open('C:/Users/saragada/Desktop/HPI/Big Deal/deal_d_2017.dat', encoding="ascii", errors="surrogateescape")
lst = []

for line in data:
    lst += [line.split('\t')]


lst1=pd.DataFrame(lst)




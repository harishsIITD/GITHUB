import pandas as pd
import os
from locale import *
import locale
import numpy as np



loc='C:/Users/saragada/Desktop/HPI/Big Deal/AUP Analysis/Refresh 2017/Raw Dump/Corp Ent/'

files = [x for x in os.listdir(loc)]

totdata=pd.DataFrame()
print(files)
for i in files:
    p=loc+i
    print(p)
    datap=pd.read_csv(p, header=0)
    totdata=pd.concat([datap,totdata],ignore_index=True)
totdata['sector']='Corp Ent'

loc='C:/Users/saragada/Desktop/HPI/Big Deal/AUP Analysis/Refresh 2017/Raw Dump/SLED/'

files = [x for x in os.listdir(loc)]

totdatasled=pd.DataFrame()
print(files)
for i in files:
    q=loc+i
    print(q)
    datap=pd.read_csv(q, header=0)
    totdatasled=pd.concat([datap,totdata],ignore_index=True)
totdatasled['sector']='SLED'

totdata=pd.concat([totdatasled,totdata],ignore_index=True)
totdata=totdata.drop_duplicates()

totdata=totdata.loc[totdata["Base Product Identifier"].str[:2] !=('EZ' or 'ez')]



totdata['Year'] = totdata['Revenue Recognition Fiscal Year Month Display Code'].str[4:6]
totdata=totdata[totdata['Year'].isnull()==False]
totdata['Month'] = totdata['Revenue Recognition Fiscal Year Month Display Code'].str[-2:]

fydata=pd.DataFrame.from_items([('Month', ['01','02','03','04','05','06','07','08','09','10','11','12']), ('B', ['Nov','Dec','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct'])])

totdata=pd.merge(totdata ,fydata, how='left', on = ['Month'])
totdata['Months by Name'] = totdata.B.str.cat(totdata.Year)
data1=pd.read_excel('C:/Users/saragada/Desktop/HPI/Big Deal/AUP Analysis/Refresh 2017/Raw Dump/Mapping and BA Mapping files.xlsx', header=0,sheetname='BA Mapping')
data2=pd.read_excel('C:/Users/saragada/Desktop/HPI/Big Deal/AUP Analysis/Refresh 2017/Raw Dump/Mapping and BA Mapping files.xlsx', header=0,sheetname='Mapping File')

totdata=pd.merge(totdata ,data1, how='left', on = ['Business Area Code'])
totdata=pd.merge(totdata ,data2, how='left', on = ['Sold To AMID Level 2 Identifier'])
totdata['Status']=totdata['Status'].fillna('No')
#totdata['Working P&L Summary Extended Quantity']=totdata['Working P&L Summary Extended Quantity'].astype(int)
#totdata['Working P&L Summary Net Revenue US Dollar Amount']=totdata['Working P&L Summary Extended Quantity'].astype(float)

#totdata['Working P&L Summary Extended Quantity']=totdata['Working P&L Summary Extended Quantity'].fillna(value=0.0,inplace=True)
#totdata['Working P&L Summary Net Revenue US Dollar Amount']=totdata['Working P&L Summary Net Revenue US Dollar Amount'].fillna(value=0,inplace=True)






totdata['Working P&L Summary Extended Quantity']=(totdata['Working P&L Summary Extended Quantity'].str.replace(r'[\$,]', '').astype(float).astype(int))
totdata['Working P&L Summary Net Revenue US Dollar Amount']=(totdata['Working P&L Summary Net Revenue US Dollar Amount'].str.replace(r'[\$,]', '').astype(float).astype(int))
Deal_Pivot=pd.pivot_table(totdata,values=['Working P&L Summary Extended Quantity','Working P&L Summary Net Revenue US Dollar Amount'],index=['sector','Status','Manufacturing Product Product Type Identifier','Manufacturing Product Product Line Description','Revenue Recognition Fiscal Year Quarter Display Code','Sold To AMID Level 2 Name','Product Category Description','Manufacturing Product Identifier','Manufacturing Product Family Description'],columns='Revenue Recognition Fiscal Year Month Display Code',aggfunc='sum')
p=Deal_Pivot.columns.values.tolist()
l=len(p)
l=int(l/2)
for i in range(0,l):
    
    Deal_Pivot[('AUP',p[i][1])]=(Deal_Pivot[p[i+3]]/Deal_Pivot[p[i]])
    Deal_Pivot.loc[~np.isfinite(Deal_Pivot[('AUP',p[i][1])]), ('AUP',p[i][1])] = np.nan
#Deal_Pivot.fillna(value=0)
Deal_Pivot1=Deal_Pivot.copy()
c=Deal_Pivot1.columns.values.tolist()
x=set(c).difference(p)
x=list(x)
reversed_x = x[::-1]

print(Deal_Pivot1.head())
for i in reversed_x:
    for j in reversed_x:
        Deal_Pivot1[i].fillna(Deal_Pivot1[j], inplace=True)
len1=len(x)        
for i in range(0,len1-1):
    Deal_Pivot1[('Change in AUP',x[i+1][1])]= Deal_Pivot1[x[i+1]]-Deal_Pivot1[x[i]]
m=Deal_Pivot1.columns.values.tolist()
x1=set(m).difference(c)
x1=list(x1)

for var in x1:
    Deal_Pivot1[('Impact in Revenue',var[1])]= Deal_Pivot1[var]*Deal_Pivot1[('Working P&L Summary Extended Quantity',var[1])]

n=Deal_Pivot1.columns.values.tolist()
x2=set(n).difference(m)
x2=list(x2)
Deal_Pivot1['Total']=0
for var2 in x2:
    Deal_Pivot1['Total']=Deal_Pivot1['Total']+Deal_Pivot1[var2]
#Deal_Pivot1=Deal_Pivot1.reset_index()
#Deal_Pivot[x1]=Deal_Pivot1[x1]
g=Deal_Pivot1.columns.values.tolist()
f=list(set(g).difference(c))


#Deal_Pivot[x2]=Deal_Pivot1[x2]
#Deal_Pivot['Total']=Deal_Pivot1['Total']  

Deal_Pivot=Deal_Pivot.join(Deal_Pivot1[f])
Deal_Pivot=Deal_Pivot1[g]

Deal_Pivot.fillna(value=0)

Deal_Pivot1.fillna(value=0)
Deal_Pivot=Deal_Pivot.reset_index()
Deal_Pivot.to_csv('changepi.csv')
Deal_Pivot1.to_csv('changepi2.csv')

del p,x,c,x1,m,n,x2
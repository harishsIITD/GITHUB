from vertica_python import connect
import jaydebeapi
table = 'Cmn_HP_Standard_Reference_Data.DEAL_D'
import pyodbc
import pandas as pd

conn_info = {'host':'**********','user': 'harish.saragadam@**.com','password': '******','database': '*******_','ssl': False}
connection = connect(**conn_info)

cur = connection.cursor()

cur.execute('''select DISTINCT PROD.PROD_ID,PROD.PROD_TYPE_ID,PROD.PROD_LN_ID,PROD.PROD_DN From Cmn_HP_Standard_Reference_Data.ENTPRS_PROD_D PROD where PROD.SPRN_CO_ID IN  ('2') ''')

rows=cur.fetchall()

totdata=pd.DataFrame(rows)
totdata=totdata.apply(lambda x: x.apply(lambda y: y.strip() if type(y) == type('') else y), axis=0)

totdata.columns=['Manufacturing Product ID','Manufacturing Product ID Product Type Identifier','Manufacturing Product Product Line Identifier','Manufacturing Product Product Description']
totdata.to_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Prod_ID.csv')
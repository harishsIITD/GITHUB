from vertica_python import connect
import jaydebeapi
table = 'Cmn_HP_Standard_Reference_Data.DEAL_D'
import pyodbc
import pandas as pd

conn_info = {'host':'**********','user': 'harish.saragadam@**.com','password': '******','database': '*******_','ssl': False}
connection = connect(**conn_info)

cur = connection.cursor()
cur.execute('''

SELECT
'0' "Dummy"
,  REBREBBD_1.BNDL_CD_DN  "Bundle Code Description"
,  IPIPD_1.INT_PRCS_CD  "Internal Process Code"
,  IPIPD_1.INT_PRCS_DN  "Internal Process Description"
,  RRDDD_1.FISC_YR_NM  "Revenue Recognition Fiscal Year Name"
,  RRDDD_1.FISC_YR_QTR_DSPLY_CD  "Revenue Recognition Fiscal Year Quarter Display Code"
,  RRDDD_1.FISC_YR_MTH_DSPLY_CD  "Revenue Recognition Fiscal Year Month Display Code"
,  BABAD_1.BUS_AREA_CD "Business Area Code"
,  BABAD_1.BUS_AREA_DN  "Business Area Description"
,  LCLCD_1.LEGL_CO_CD  "Legal Company Code"
,  LCLCD_1.LEGL_CO_NM  "Legal Company Name"
,  PCPCD_1.PRFT_CTR_LVL_0_DN  "Profit Center Level 0 Description"
,  PCPCD_1.PRFT_CTR_LVL_1_DN  "Profit Center Level 1 Description"
,  PCPCD_1.PRFT_CTR_LVL_2_DN  "Profit Center Level 2 Description"
,  PCPCD_1.PRFT_CTR_LVL_3_DN  "Profit Center Level 3 Description"
,  PCPCD_1.PRFT_CTR_LVL_4_DN  "Profit Center Level 4 Description"
,  PCPCD_1.PRFT_CTR_LVL_5_DN  "Profit Center Level 5 Description"
,  PCPCD_1.PRFT_CTR_CD  "Profit Center Code"
,  PCPCD_1.PRFT_CTR_DN  "Profit Center Description"
,  PEPD_1.PROD_LN_ID   "Manufacturing Product Product Line Identifier"
,  PEPD_1.PROD_LN_DN  "Manufacturing Product Product Line Description"
,  PEPD_1.PROD_TYPE_ID  "Manufacturing Product Product Type Identifier"
,  PEPD_1.PROD_TYPE_DN  "Manufacturing Product Product Type Description"
,  PEPD_1.TYPE_ID  "Manufacturing Product Type Identifier"
,  PEPD_1.TYPE_DN  "Manufacturing Product Type Description"
,  PEPD_1.LN_ID  "Manufacturing Product Line Identifier"
,  PEPD_1.LN_DN  "Manufacturing Product Line Description"
,  PEPD_1.PROD_FMLY_DN  "Manufacturing Product Family Description"
,  PEPD_1.PROD_FMLY_ID  "Manufacturing Product Family Identifier"
,  PEPD_1.PROD_ID  "Manufacturing Product Identifier"
,  PEPD_1.PROD_DN  "Manufacturing Product Description"
,  OEPD_1.PROD_ID  "Base Product Identifier"
,  OEPD_1.PROD_DN  "Base Product Description"
,  PEPD_1.MDL_UNITS_PER_SKU_QT  "Manufacturing Product Model Units Per Product Identifier Quantity"
,  STCHD_1.CUST_AMID_LVL_2_ID  "Sold To AMID Level 2 Identifier"
,  STCHD_1.CUST_AMID_LVL_2_NM  "Sold To AMID Level 2 Name"
,  SCSCD_1.SLS_CHNL_CD  "Sales Channel Code"
,  SCSCD_1.SLS_CHNL_NM  "Sales Channel Name"
,  SCSCD_1.SLS_CHNL_RTE_NM  "Sales Channel Route Name"
,  WPALWPDFV_1.SLS_ORG_CD  "Sales Organization Code"
,  WPALWPDFV_1.POST_TYPE_CD  "Posting Type Code"
,  SSSSD_1.SRC_SYS_KY  "Source System Code"
,  SSSSD_1.SRC_SYS_DN  "Source System Description"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.WRKING_PNL_QT  END) END) "Working P&L Summary Base Quantity"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.WRKING_PNL_EXT_QT  END) END) "Working P&L Summary Extended Quantity"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.WRKING_PNL_OPT_QT  END) END) "Working P&L Summary Product ID Quantity"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.WRKING_PNL_SLS_QT  END) END) "Working P&L Summary Sales Quantity"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
WHEN( PPSPTDV_1.SLS_PROD_TYPE_ID  = 'UN') THEN  WPALWPDFV_1.WRKING_PNL_EXT_QT 
ELSE 0 END)"Working P&L Summary Unit Quantity"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.GRS_REV_WRKING_PNL_USD_AM  END) END) "Working P&L Summary Gross Revenue US Dollar Amount"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.TRD_DISCS_USD_AM  END) END) "Working P&L Summary Discount US Dollar Amount"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.NET_DEALER_PRC_USD_AM  END) END) "Working P&L Summary Net Dealer Price US Dollar Amount"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.NET_REV_WRKING_PNL_USD_AM  END) END) "Working P&L Summary Net Revenue US Dollar Amount"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.ENTPRS_STD_CST_USD_AM  END) END) "Working P&L Summary Enterprise Standard Cost US Dollar Amount"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.TOT_CST_OF_SLS_USD_AM  END) END) "Working P&L Summary Total Cost Of Sales US Dollar Amount"
, SUM(CASE
WHEN( WPALWPDFV_1.MRGN_FOCUS_CD  = 'S' OR  WPALWPDFV_1.INT_PRCS_CD  = 'IFS2_ADJ') THEN 0
ELSE (CASE
WHEN( WPALWPDFV_1.WRKING_PNL_VSBL_FG  = 'N') THEN 0
ELSE  WPALWPDFV_1.GRS_MRGN_USD_AM  END) END) "Working P&L Summary Gross Margin US Dollar Amount"
FROM
Cmn_Financial_Margin.WRKING_PNL_DTL_F "WPALWPDFV_1"
INNER JOIN Cmn_HP_Standard_Reference_Data.REC_EXPLN_BNDL_B_D "REBREBBD_1"
ON ( WPALWPDFV_1.REC_EXPLN_CD  =  REBREBBD_1.REC_EXPLN_CD )
INNER JOIN Cmn_HP_Standard_Reference_Data.INT_PRCS_D "IPIPD_1"
ON ( WPALWPDFV_1.INT_PRCS_CD  =  IPIPD_1.INT_PRCS_CD )
INNER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D "RRDDD_1"
ON ( WPALWPDFV_1.REV_RECGN_DT  =  RRDDD_1.CLDR_DT )
INNER JOIN Cmn_HP_Standard_Reference_Data.BUS_AREA_D "BABAD_1"
ON ( WPALWPDFV_1.BUS_AREA_CD  =  BABAD_1.BUS_AREA_CD  AND BABAD_1.SPRN_CO_ID = '2')
INNER JOIN Cmn_HP_Standard_Reference_Data.LEGL_CO_D "LCLCD_1"
ON ( WPALWPDFV_1.LEGL_CO_CD  =  LCLCD_1.LEGL_CO_CD  AND LCLCD_1.SPRN_CO_ID = '2')
INNER JOIN Cmn_HP_Standard_Reference_Data.PRFT_CTR_D "PCPCD_1"
ON ( WPALWPDFV_1.PRFT_CTR_CD  =  PCPCD_1.PRFT_CTR_CD  AND PCPCD_1.SPRN_CO_ID = '2')
INNER JOIN Cmn_HP_Standard_Reference_Data.ENTPRS_PROD_D "OEPD_1"
ON ( WPALWPDFV_1.ORIG_PROD_ID  =  OEPD_1.PROD_ID  AND OEPD_1.SPRN_CO_ID = '2')
INNER JOIN Cmn_HP_Standard_Reference_Data.ENTPRS_PROD_D "PEPD_1"
ON ( WPALWPDFV_1.PROD_ID  =  PEPD_1.PROD_ID  AND PEPD_1.SPRN_CO_ID = '2')
INNER JOIN Cmn_HP_Standard_Reference_Data.PROD_SLS_PROD_TYPE_D_V "PPSPTDV_1"
ON (PEPD_1.PROD_ID = PPSPTDV_1.PROD_ID AND PPSPTDV_1.SPRN_CO_ID = '2')
LEFT OUTER JOIN Cmn_HP_Standard_Reference_Data.CUST_HIER_D "STCHD_1"
ON ( WPALWPDFV_1.SLDT_CUST_ID  =  STCHD_1.CUST_ID )
INNER JOIN Cmn_HP_Standard_Reference_Data.SLS_CHNL_D "SCSCD_1"
ON ( WPALWPDFV_1.SLS_CHNL_CD  =  SCSCD_1.SLS_CHNL_CD  AND SCSCD_1.SPRN_CO_ID = '2')
INNER JOIN Cmn_HP_Standard_Reference_Data.SRC_SYS_D "SSSSD_1"
ON ( WPALWPDFV_1.SRC_SYS_KY  =  SSSSD_1.SRC_SYS_KY )
WHERE
(WPALWPDFV_1.SPRN_CO_ID IN ('1','2') AND ( REBREBBD_1.BNDL_CD_DN  IN ('BUNDLE') AND  RRDDD_1.FISC_YR_NM  IN ('FY2017','FY2018') AND  WPALWPDFV_1.SLS_ORG_CD  = 'CEI3' AND ( BABAD_1.GBL_BUS_UNIT_ID  = 'HPBA_WW186' OR  BABAD_1.GBL_BUS_UNIT_ID  = 'HPBA_WW209' OR  BABAD_1.GBL_BUS_UNIT_ID  = 'HPBA_WW220' OR  BABAD_1.GBL_BUS_UNIT_ID  = 'HPBA_WW64' OR  BABAD_1.SUBGRP_ID  = 'HPBA_WW225' OR  BABAD_1.GBL_BUS_UNIT_ID  = 'HPBA_WW189' OR  BABAD_1.GBL_BUS_UNIT_ID  = 'HPBA_WW223' OR  BABAD_1.GBL_BUS_UNIT_ID  = 'HPBA_WW234')))
GROUP BY
2
, 3
, 4
, 5
, 6
, 7
, 8
, 9
, 10
, 11
, 12
, 13
, 14
, 15
, 16
, 17
, 18
, 19
, 20
, 21
, 22
, 23
, 24
, 25
, 26
, 27
, 28
, 29
, 30
, 31
, 32
, 33
, 34
, 35
, 36
, 37
, 38
, 39
, 40
, 41
, 42
, 43''')
rows=cur.fetchall()
totdata=pd.DataFrame(rows)

columns=["Index","Bundle Code Description",	"Internal Process Code",	"Internal Process Description",	"Revenue Recognition Fiscal Year Name",	"Revenue Recognition Fiscal Year Quarter Display Code",	"Revenue Recognition Fiscal Year Month Display Code",	"Business Area Code",	"Business Area Description",	"Legal Company Code",	"Legal Company Name",	"Profit Center Level 0 Description",	"Profit Center Level 1 Description",	"Profit Center Level 2 Description",	"Profit Center Level 3 Description",	"Profit Center Level 4 Description",	"Profit Center Level 5 Description",	"Profit Center Code",	"Profit Center Description",	"Manufacturing Product Product Line Identifier",	"Manufacturing Product Product Line Description",	"Manufacturing Product Product Type Identifier",	"Manufacturing Product Product Type Description",	"Manufacturing Product Type Identifier",	"Manufacturing Product Type Description",	"Manufacturing Product Line Identifier",	"Manufacturing Product Line Description",	"Manufacturing Product Family Description",	"Manufacturing Product Family Identifier",	"Manufacturing Product Identifier",	"Manufacturing Product Description",	"Base Product Identifier",	"Base Product Description",	"Manufacturing Product Model Units Per Product Identifier Quantity",	"Sold To AMID Level 2 Identifier",	"Sold To AMID Level 2 Name",	"Sales Channel Code",	"Sales Channel Name",	"Sales Channel Route Name",	"Sales Organization Code",	"Posting Type Code",	"Source System Code",	"Source System Description",	"Working P&L Summary Base Quantity",	"Working P&L Summary Extended Quantity",	"Working P&L Summary Product ID Quantity",	"Working P&L Summary Sales Quantity",	"Working P&L Summary Unit Quantity",	"Working P&L Summary Gross Revenue US Dollar Amount",	"Working P&L Summary Discount US Dollar Amount",	"Working P&L Summary Net Dealer Price US Dollar Amount",	"Working P&L Summary Net Revenue US Dollar Amount",	"Working P&L Summary Enterprise Standard Cost US Dollar Amount",	"Working P&L Summary Total Cost Of Sales US Dollar Amount",	"Working P&L Summary Gross Margin US Dollar Amount"]
totdata.columns=columns
totdata['Sector']='Corp Ent'

import pandas as pd
import numpy as np
from sklearn import preprocessing
import random
import pandas as pd
import numpy as np
from sklearn import preprocessing
import random
random.seed(90)
from sklearn.neural_network import MLPClassifier
print('Random',random.random())
import matplotlib as plt
from sklearn.preprocessing import StandardScaler  
from sklearn import model_selection
from sklearn.metrics import accuracy_score
from numpy import corrcoef, sum, log, arange
from numpy.random import rand
from pylab import pcolor, show, colorbar, xticks, yticks
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
import sklearn.svm as svm
from sklearn.cross_validation import cross_val_score, train_test_split
import numpy as np
from sklearn import preprocessing,cross_validation,svm,neighbors
import pandas as pd
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.datasets.samples_generator import make_blobs
from sklearn.preprocessing import StandardScaler
totdata = totdata.reset_index()

data1=totdata.groupby(['Sold To AMID Level 2 Identifier']).sum()

data2=data1.sort_values(['Working P&L Summary Net Revenue US Dollar Amount'], ascending=[0])
#data3=data2[:100]
data3=data2
data3 = data3.reset_index()

predictors=data3.columns.drop(['Sold To AMID Level 2 Identifier','Working P&L Summary Enterprise Standard Cost US Dollar Amount'])

X = np.asarray(data3[predictors])
X=preprocessing.robust_scale(X, axis=0, with_centering=True, with_scaling=True, quantile_range=(25.0, 75.0), copy=True)

db = DBSCAN(eps=0.2, min_samples=5).fit(X)
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
labels = db.labels_

# Number of clusters in labels, ignoring noise if present.
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)

print('Estimated number of clusters: %d' % n_clusters_)

import matplotlib.pyplot as plt

# Black removed and is used for noise instead.
unique_labels = set(labels)
colors = [plt.cm.Spectral(each)
          for each in np.linspace(0, 1, len(unique_labels))]
for k, col in zip(unique_labels, colors):
    if k == -1:
        # Black used for noise.
        col = [0, 0, 0, 1]

    class_member_mask = (labels == k)

    xy = X[class_member_mask & core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=14)

    xy = X[class_member_mask & ~core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=6)

plt.title('Estimated number of clusters: %d' % n_clusters_)
plt.show()



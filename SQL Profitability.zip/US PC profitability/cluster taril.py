import pandas as pd
import numpy as np
from sklearn import preprocessing
import random
import pandas as pd
import numpy as np
from sklearn import preprocessing
import random
#random.seed(90)
from sklearn.neural_network import MLPClassifier
print('Random',random.random())
import matplotlib as plt
from sklearn.preprocessing import StandardScaler  
from sklearn import model_selection
from sklearn.metrics import accuracy_score
from numpy import corrcoef, sum, log, arange
from numpy.random import rand
from pylab import pcolor, show, colorbar, xticks, yticks
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
import sklearn.svm as svm
from sklearn.cross_validation import cross_val_score, train_test_split
import numpy as np
from sklearn import preprocessing,cross_validation,svm,neighbors
import pandas as pd
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.datasets.samples_generator import make_blobs
from sklearn.preprocessing import StandardScaler

data=pd.read_excel('C:/Users/saragada/Desktop/HPI/AUP/clustering data 1718.xlsx')

data1=data.groupby(['Sold To AMID Level 2 Identifier']).sum()
data2=data1.sort_values(['Working P&L Summary Net Revenue US Dollar Amount'], ascending=[0])
#data3=data2[:100]
data3=data2
data3 = data3.reset_index()
data3=data3[(data3['Working P&L Summary Extended Quantity']>0) & (data3['Working P&L Summary Net Revenue US Dollar Amount']>0)]

predictors=data3.columns.drop(['Sold To AMID Level 2 Identifier'])

X = np.asarray(data3[predictors])
X=preprocessing.robust_scale(X, axis=0, with_centering=True, with_scaling=True, quantile_range=(25.0, 75.0), copy=True)

db = DBSCAN(eps=0.06, min_samples=5).fit(X)
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
labels = db.labels_

# Number of clusters in labels, ignoring noise if present.
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)

print('Estimated number of clusters: %d' % n_clusters_)

import matplotlib.pyplot as plt

# Black removed and is used for noise instead.
unique_labels = set(labels)
colors = [plt.cm.Spectral(each)
          for each in np.linspace(0, 1, len(unique_labels))]
for k, col in zip(unique_labels, colors):
    if k == -1:
        # Black used for noise.
        col = [0,0,0,1]

    class_member_mask = (labels == k)

    xy = X[class_member_mask & core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=14)

    xy = X[class_member_mask & ~core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=16)

plt.title('Estimated number of clusters: %d' % n_clusters_)
plt.show()
labels=list(labels)


from sklearn.cluster import KMeans
from sklearn import metrics
from scipy.spatial.distance import cdist
import numpy as np
import matplotlib.pyplot as plt
 
 

 
#plt.plot()
#plt.xlim([0, 10])
#plt.ylim([0, 10])
#plt.title('Dataset')
#plt.scatter(x1, x2)
#plt.show()
# 
## create new plot and data
#plt.plot()
#X = np.array(list(zip(x1, x2))).reshape(len(x1), 2)
#colors = ['b', 'g', 'r']
#markers = ['o', 'v', 's']
# 
# k means determine k
distortions = []
K = range(1,10)
for k in K:
    kmeanModel = KMeans(n_clusters=k).fit(X)
    kmeanModel.fit(X)
    distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / X.shape[0])
 
# Plot the elbow
plt.plot(K, distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('The Elbow Method showing the optimal k')
plt.show()


from sklearn.metrics import silhouette_score

from sklearn.cluster import KMeans


for n_cluster in range(3, 11):
    kmeans = KMeans(n_clusters=n_cluster).fit(X)
    label = kmeans.labels_
    sil_coeff = silhouette_score(X, label, metric='euclidean')
    print("For n_clusters={}, The Silhouette Coefficient is {}".format(n_cluster, sil_coeff))
    
    
kmeans = KMeans(n_clusters=4).fit(X)

kmeanslabel = kmeans.labels_

colors = ['b', 'g', 'r', 'o']
plt.plot()
for i, l in enumerate(kmeans.labels_):
    plt.plot(X[i,0], X[i,1], color=colors[l],ls='None')
    plt.xlim([-100, 100])
    plt.ylim([-100, 100])
 
plt.show()
kmeanslabel=list(kmeanslabel)

data3['KmeansLables']=kmeanslabel
data3['DBSCANLables']=labels


import os
import pandas as pd
import numpy as np
Prod_data=pd.read_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Prod_ID.csv',encoding='latin-1',index_col=False)

Prod_data = Prod_data.drop('Unnamed: 0', 1)
#Prod_data.columns=['Manufacturing Product ID','Manufacturing Product ID Product Type Identifier','Manufacturing Product Product Line Identifier','Manufacturing Product Product Description']

Cust_data=pd.read_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Cust_table.csv',encoding='latin-1',index_col=False)

Cust_data=Cust_data.apply(lambda x: x.apply(lambda y: y.strip() if type(y) == type('') else y), axis=0)
Cust_data = Cust_data.drop('Unnamed: 0', 1)



loc='C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Big Deal complete data/'

files = [x for x in os.listdir(loc)]
for j in files:

    print(j)
    totdata=pd.read_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Big Deal complete data/'+str(j),encoding='latin-1')
    totdata = totdata.drop('Unnamed: 0', 1)
    
    totdata.columns=['Deal ID','Deal Begin Calendar Date MM DD YYYY Code','Deal End Calendar Date MM DD YYYY Code','Business Model Description','Deal Version Number','Deal Line Type Code','Miscellaneous Charge Code','Win Loss Status Code','Sales Rep Workforce Full Name','District Manager Workforce Full Name','Eclipse Customer Name','Eclipse Customer Segment Code','Customer ID','Profit Center Level 3 Name','Deal Line Type Description','Manufacturing Product ID','Line Authorized Calendar Date MM DD YYYY Code','Quantity','Quoted Gross Revenue @NDP US Dollar Amount','Latest Gross Revenue @ LP US Dollar Amount','Quoted BDNet Revenue US Dollar Amount','Latest BD Net Revenue US Dollar Amount','Quoted Gross Margin US Dollar Amount','Latest Gross Margin US Dollar Amount','Latest Authorized Unit BDNet Price US Dollar Amount']
    totdata['Deal Index']=j
    totdata=totdata.apply(lambda x: x.apply(lambda y: y.strip() if type(y) == type('') else y), axis=0)
    totdata=pd.merge(totdata, Cust_data, on='Customer ID', how='inner')
    totdata=pd.merge(totdata, Prod_data, on='Manufacturing Product ID', how='inner')
      #  totdata=totdata[totdata['Manufacturing Product ID Product Type Identifier']=='UN']
     #   totdata=totdata[totdata['Deal Line Type Code']=='PN']
      #  totdata['Latest Authorized Unit BDNet Price US Dollar Amount']=(totdata['Latest Authorized Unit BDNet Price US Dollar Amount'].str.replace(r'[\$,]', '').astype(float).astype(int))
    Deal_Pivot=pd.pivot_table(totdata,values='Latest Authorized Unit BDNet Price US Dollar Amount',index=['Eclipse Customer Name','Customer Account Management Identifier Level 2 Identifier','Deal ID','Manufacturing Product ID','Manufacturing Product Product Line Identifier','Manufacturing Product ID Product Type Identifier','Deal Line Type Code','Deal Version Number','Line Authorized Calendar Date MM DD YYYY Code'],aggfunc='sum')
    
    Deal_Pivot['Diff Value'] = Deal_Pivot.groupby(['Eclipse Customer Name','Deal ID','Manufacturing Product ID'])['Latest Authorized Unit BDNet Price US Dollar Amount'].diff()
    Deal_Pivot.fillna(value=0, inplace=True)
    Deal_Pivot['status']='No'
    Deal_Pivot['status'][Deal_Pivot['Diff Value']>0]='Yes'
    
    Deal_Pivot.loc[(Deal_Pivot['Diff Value']>0),'Inc or dec']='Price Increased'
    Deal_Pivot.loc[(Deal_Pivot['Diff Value']<0),'Inc or dec']='Price Decreased'
    Deal_Pivot.loc[Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount']==0,'Inc or dec']='SKU Removed'
    Deal_Pivot.loc[(Deal_Pivot['Diff Value']==0),'Inc or dec']='No Change'
    Deal_Pivot['BDL Price Before the change']=Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount']-Deal_Pivot['Diff Value']
    deallen=len(Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'])
    Deal_Pivot=Deal_Pivot.reset_index()
    Deal_Pivot['combined']=Deal_Pivot['Deal ID'].astype(str)+'_'+Deal_Pivot['Manufacturing Product ID']
       
    
    unique_list=Deal_Pivot['combined'].unique()
    c=0
    for i in range(1,deallen):
        if Deal_Pivot['combined'][i-1]==Deal_Pivot['combined'][i] and Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'][i-1]==0 and Deal_Pivot['Latest Authorized Unit BDNet Price US Dollar Amount'][i]>0:
            Deal_Pivot['Inc or dec'][i]='Sku Added'
            
        
    Deal_Pivot.to_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Complete Deal Data/Output2/'+str(j))
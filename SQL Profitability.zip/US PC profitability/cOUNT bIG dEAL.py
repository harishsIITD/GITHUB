from vertica_python import connect
import jaydebeapi
table = 'Cmn_HP_Standard_Reference_Data.DEAL_D'
import pyodbc
import pandas as pd

conn_info = {'host':'**********','user': 'harish.saragadam@**.com','password': '******','database': '*******_','ssl': False}
connection = connect(**conn_info)

cur = connection.cursor()

cur.execute('''select COUNT(DISTINCT DEALA.DEAL_ID) from Cmn_Deal.DEAL_LN_AUDIT_F DEALA 
INNER JOIN Cmn_HP_Standard_Reference_Data.DEAL_D DEALD 
      ON ( DEALA.DEAL_ID  =  DEALD.DEAL_ID  AND  DEALA.DEAL_VERS_NR  =  DEALD.DEAL_VERS_NR  AND DEALD.SPRN_CO_ID IN ('1','2') AND DEALD.DEAL_END_DT >'02/01/2017')
INNER JOIN Cmn_HP_Standard_Reference_Data.BUS_AREA_D BA
      ON ( DEALA.BUS_AREA_CD  =  BA.BUS_AREA_CD  AND BA.SPRN_CO_ID = '2' AND BA.EXT_SEG_CD  ='HPBA_WW52' )
INNER JOIN Cmn_HP_Standard_Reference_Data.PRFT_CTR_D PFTC
      ON ( DEALA.PRFT_CTR_CD  =  PFTC.PRFT_CTR_CD  AND PFTC.SPRN_CO_ID = '2' and PFTC.PRFT_CTR_LVL_2_CD  = 'PCG00903')
INNER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE1
      ON ( DEALD.DEAL_BEGIN_DT  =  DATE1.CLDR_DT )
INNER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE2
      ON ( DEALD.DEAL_END_DT  =  DATE2.CLDR_DT )
INNER JOIN Cmn_HP_Standard_Reference_Data.DEAL_BUS_MDL_D BMDL
      ON ( DEALD.BUS_MDL_CD  =  BMDL.BUS_MDL_CD  AND  DEALD.ISO_CTRY_CD  =  BMDL.GEO_CD  AND BMDL.SPRN_CO_ID = '2')
INNER JOIN Cmn_HP_Standard_Reference_Data.CUST_HIER_D CUST
      ON ( DEALA.DRVD_END_CUST_ID  =  CUST.CUST_ID )      
LEFT OUTER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE3
      ON ( DEALA.LN_AUTH_DT  =  DATE3.CLDR_DT )       
INNER JOIN Cmn_HP_Standard_Reference_Data.ENTPRS_PROD_D PROD
      ON ( DEALA.PROD_ID  =  PROD.PROD_ID  AND PROD.SPRN_CO_ID = '2')''')
count = cur.fetchone()[0]
batch_size = 10000
c=0

for offset in range(0, count, batch_size):
    cur.execute('''
    SELECT DISTINCT DEALD.DEAL_ID          
    from Cmn_Deal.DEAL_LN_AUDIT_F DEALA 
    INNER JOIN Cmn_HP_Standard_Reference_Data.DEAL_D DEALD 
          ON ( DEALA.DEAL_ID  =  DEALD.DEAL_ID  AND  DEALA.DEAL_VERS_NR  =  DEALD.DEAL_VERS_NR  AND DEALD.SPRN_CO_ID IN ('1','2') AND DEALD.DEAL_END_DT > '02/01/2017')
    INNER JOIN Cmn_HP_Standard_Reference_Data.BUS_AREA_D BA
          ON ( DEALA.BUS_AREA_CD  =  BA.BUS_AREA_CD  AND BA.SPRN_CO_ID = '2' AND BA.EXT_SEG_CD  ='HPBA_WW52' )
    INNER JOIN Cmn_HP_Standard_Reference_Data.PRFT_CTR_D PFTC
          ON ( DEALA.PRFT_CTR_CD  =  PFTC.PRFT_CTR_CD  AND PFTC.SPRN_CO_ID = '2' and PFTC.PRFT_CTR_LVL_2_CD  = 'PCG00903')
    INNER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE1
          ON ( DEALD.DEAL_BEGIN_DT  =  DATE1.CLDR_DT )
    INNER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE2
          ON ( DEALD.DEAL_END_DT  =  DATE2.CLDR_DT )
    INNER JOIN Cmn_HP_Standard_Reference_Data.DEAL_BUS_MDL_D BMDL
          ON ( DEALD.BUS_MDL_CD  =  BMDL.BUS_MDL_CD  AND  DEALD.ISO_CTRY_CD  =  BMDL.GEO_CD  AND BMDL.SPRN_CO_ID = '2')
    INNER JOIN Cmn_HP_Standard_Reference_Data.CUST_HIER_D CUST
          ON ( DEALA.DRVD_END_CUST_ID  =  CUST.CUST_ID )      
    LEFT OUTER JOIN Cmn_HP_Standard_Reference_Data.DT_DAY_D DATE3
          ON ( DEALA.LN_AUTH_DT  =  DATE3.CLDR_DT )       
    INNER JOIN Cmn_HP_Standard_Reference_Data.ENTPRS_PROD_D PROD
          ON ( DEALA.PROD_ID  =  PROD.PROD_ID  AND PROD.SPRN_CO_ID = '2')
     LIMIT %s OFFSET %s ''',(batch_size, offset))
    rows=cur.fetchall()
    totdata=pd.DataFrame(rows)
    c=c+1
    totdata.to_csv('C:/Users/saragada/Desktop/HPI/Big Deal/Sheila Wall/Total Deals/Deallist'+str(c)+'.csv')